package com.jcombat;;;

public class test {

	public test() {
		// TODO Auto-generated constructor stub
	}

}
