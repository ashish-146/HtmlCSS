package com.example.seconddemo;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeconddemoApplicationTests {

	@Test
	void contextLoads() {
		 SeconddemoApplication tester = new SeconddemoApplication();
		 
//		 assertEquals(0, tester.multiply(10, 0), "10 x 0 must be 0");
//	        assertEquals(0, tester.multiply(0, 10), "0 x 10 must be 0");
//	        assertEquals(0, tester.multiply(0, 0), "0 x 0 must be 0");
		 
		 String str = "Junit is working fine";
	      assertEquals("Junit is working fine",str);
	      
	}

}
